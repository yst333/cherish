import React from 'react';
import '../css/GoodsAlbum.css';


import { Swiper, SwiperSlide } from "swiper/react"; // basic
import "swiper/css"; //basic



const GoodsAlbum = () => {
    return (
      <div>
        <Swiper
        spaceBetween={20}
        slidesPerView={3}
        scrollbar={{ draggable: true }}
        // breakpoints={{
        //   768: {
        //     slidesPerView: 7,
        //   },
        // }}
        >
        <SwiperSlide className='swiper_album' >
            <img src="https://cdn-contents.weverseshop.io/public/shop/d439cb82204d8902c2612a5c9912fb62.png" alt='블랙핑크_앨범'/>
        </SwiperSlide>
        <SwiperSlide className='swiper_album'>
          <img src="	https://cdn-contents.weverseshop.io/public/shop/82626250f824e4d047166786310a8393.png" alt='뉴진스_앨범'/>
        </SwiperSlide>
        <SwiperSlide className='swiper_album'>
          <img src="	https://cdn-contents.weverseshop.io/public/shop/94b98c6ca8dd645dede4acdaad12cf2f.png" alt='투모로우바이투게터_앨범'/>
        </SwiperSlide>
        <SwiperSlide className='swiper_album'>
          <img src="https://cdn-contents.weverseshop.io/public/shop/ee5fbc57f09fb329cf28052d53f920b6.png" alt='XG_앨범'/>
        </SwiperSlide>
        <SwiperSlide className='swiper_album'>
          <img src="https://cdn-contents.weverseshop.io/public/shop/9c0b652f5c8c373eb340eb59fe31ad5a.png" alt='르세라핌_앨범'/>
        </SwiperSlide>
        <SwiperSlide className='swiper_album'>
          <img src="https://cdn-contents.weverseshop.io/public/shop/285eb3a9bbf0b867ea056a49cfbcc874.png" alt='여자아이들_앨범'/>
        </SwiperSlide>
        <SwiperSlide className='swiper_album'>
          <img src="	https://cdn-contents.weverseshop.io/public/shop/9e2d39475d951bd7d62516c82d43ce00.png" alt='샤이니_앨범'/>
        </SwiperSlide>
      </Swiper>
      </div>
    );
};

export default GoodsAlbum;