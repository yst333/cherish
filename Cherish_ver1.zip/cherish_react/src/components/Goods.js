import React from "react";
import {BrowserRouter,Route, Link} from 'react-router-dom'; //import해줘야함
import lights from './lights';
import items from './items';
import album from './album';
import GoodsAlbum from './GoodsAlbum'
import membership from './membership'
import '../css/Goods.css';

// import Container from "react-bootstrap/Container";
// const location_name = "방송통신위원회";


const Goods = () => {
    return (
        <BrowserRouter>
            <div className='container'>
                <h3 className='GoodsTitle'>cherish for you</h3>
                <ul className="GoodsSubtit">
                    <li>
                        <Link to="/Goods/lights">Light Stick</Link>
                    </li>
                    <li>
                        <Link to="/Goods/album">Album</Link>
                    </li>
                    <li>
                        <Link to="/Goods/items">Goods</Link>
                    </li>
                    <li>
                        <Link to="/Goods/membership">Membership</Link>
                    </li>
                </ul>
                <Route path="/Goods/lights" component={lights}/>
                <Route path="/Goods/album" component={album} />
                <Route path="/Goods/items" component={items} />
                <Route path="/Goods/membership" component={membership} />
                <h3 className='GoodsTitle'>new for you</h3>
                <GoodsAlbum />
            </div>
        </BrowserRouter>
    );
};

export default Goods;
