import React from 'react';
import '../css/GoodsItem.css';


const lights = () => {
    return (
        <div>
            <ul className='GoodsUl'>
                <li className='GoodsLi'>
                    <div>
                    <img src="https://cdn-contents.weverseshop.io/public/shop/0a3506d263549998bc237e5f26e99597.png" alt="뉴진스_앨범" />
                        <section>
                            <em>Newjeans</em>
                            <p>2nd EP 'Get Up' THE POWERPUFF GIRLS X NJ Box ver.</p>
                            <strong>₩39,800</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/9c6a03b0bf859cfabe1533cd84aaa55e.png" alt="르세라핌_앨범" />
                        <section>
                            <em>LE SSERAFIM</em>
                            <p>1st Album 'UNFORGIVEN' (COMPACT Ver.) </p>
                            <strong>₩12,600</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img  src="https://cdn-contents.weverseshop.io/public/shop/5c0b6d4ce9b03b6c011479b01d6b4163.jpg" alt="에스파_앨범" />
                        <section>
                            <em>aespa</em>
                            <p>3rd Mini Album ’MY WORLD’ (SMini Ver.)</p>
                            <strong>₩18,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/d04756b7a3a4979086fb61f64536b0bc.png" alt="더보이즈_앨범" />
                        <section>
                            <em>BlackPink</em>
                            <p>2nd Album [PHANTASY] (Holiday ver.)</p>
                            <strong>₩17,800</strong>
                        </section>
                    </div>
                </li>
            </ul>
                       <ul className='GoodsUl'>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/fbe9da06707b0928148758df0593eefe.png" alt="세븐틴_앨범" />
                        <section>
                            <em>SEVENTEEN</em>
                            <p>BEST ALBUM「ALWAYS YOURS」 5 SET</p>
                            <strong>₩188,400</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/56fca621882bf3bd2f5431cb3e1857f8.png" alt="스테이씨_앨범" />
                        <section>
                            <em>STAYC</em>
                            <p>Single Album [Teddy Bear] (Digipack Ver.)</p>
                            <strong>₩12,400</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/2f758e39473410af472704c9c2ed300e.png" alt="블랙핑크_앨범" />
                        <section>
                            <em>BlackPink</em>
                            <p>THE GAME PHOTOCARD COLLECTION No.1~3 (RANDOM)</p>
                            <strong>₩11,800</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/bcaf9a83ee6f526688c54e9175e14228.png" alt="보이넥스트도어_앨범" />
                        <section>
                            <em>BOYNEXTDOOR</em>
                            <p>[YOU&ME] JENNIE ART POSTER + STICKER</p>
                            <strong>₩11,100</strong>
                        </section>
                    </div>
                </li>
            </ul>
        </div>
    );
};

export default lights;