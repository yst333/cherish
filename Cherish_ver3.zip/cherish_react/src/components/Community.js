import React, { Component } from 'react';
import Container from 'react-bootstrap/Container';
import { BrowserRouter,Route,Link,Switch } from "react-router-dom";
import BoardService from './BoardService';
import '../css/community.css';
import ViewButton from './ViewButton';
import InputForm from "./InputForm";


//import Button from 'react-bootstrap/Button';
// https://react-bootstrap.netlify.app/docs/components/buttons

class Community extends Component {
    constructor(props){
        super(props)
        // 1단계 소스 코딩
        this.state = {
            boards: [] //상태값을 보드 배열에 담기
        }
    }

    // 2단계 소스 코딩
    componentDidMount(){
        BoardService.getBoards().then((res) => {
            this.setState({boards: res.data});
        });
    }

    render() {
        return (

            <BrowserRouter>
                <Container>
                <section className='commu_artist'>
                    <img className="commu_logo" src='/images/Cherish_logo_render.svg'/>
                    <img className="commu_img" src='/images/lesserafim_board.svg'/>
                </section>
                <h2 className='text-center'>게시글 목록조회</h2>
                <div className='row'>
                    <table className='table_list'>
                        <thead>
                            <tr>
                                <th>글번호</th>
                                <th>글제목</th>
                                <th>글내용</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.boards.map( //**map함수 메서드로 반복해서 여러개 가져온다. 
                                    board =>
                                    <tr key = {board.articleId}> {/*key구분*/}
                                        <td>{board.articleId}</td>
                                        <td>{board.articleTitle}</td>
                                        <td>{board.articleContent}</td>
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                    <Link to="/">
                        <button type="button">처음으로!</button>
                    </Link>
                </div>
                <Switch>
                    <ViewButton />
                    <Route exact path="/" component={ViewButton} />
                    <Route exact path="/:crud" component={InputForm} />  
                </Switch>
                </Container>                
            </BrowserRouter>
     );
   }
}


export default Community;