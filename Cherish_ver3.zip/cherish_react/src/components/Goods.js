import React from "react";
import {BrowserRouter,Route, Link} from 'react-router-dom'; //import해줘야함
import Lights from './Lights';
import Items from './Items';
import Album from './Album';
import GoodsAlbum from './GoodsAlbum'
import Membership from './Membership'
import '../css/goods.css';

// import Container from "react-bootstrap/Container";
// const location_name = "방송통신위원회";


const Goods = () => {
    return (
        <BrowserRouter>
            <div className='container'>
                <h3 className='GoodsTitle'>cherish for you</h3>
                <ul className="GoodsSubtit">
                    <li>
                        <Link to="/Goods/lights">Light Stick</Link>
                    </li>
                    <li>
                        <Link to="/Goods/album">Album</Link>
                    </li>
                    <li>
                        <Link to="/Goods/items">Goods</Link>
                    </li>
                    <li>
                        <Link to="/Goods/membership">Membership</Link>
                    </li>
                </ul>
                <Route path="/Goods/lights" component={Lights}/>
                <Route path="/Goods/album" component={Album} />
                <Route path="/Goods/items" component={Items} />
                <Route path="/Goods/membership" component={Membership} />
                <h3 className='GoodsTitle'>new for you</h3>
                <GoodsAlbum />
            </div>
        </BrowserRouter>
    );
};

export default Goods;
