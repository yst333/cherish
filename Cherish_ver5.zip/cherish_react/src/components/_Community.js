import React, { Component } from 'react';
import Container from 'react-bootstrap/Container';
import { Route,Link,Switch } from "react-router-dom";

import BoardService from './BoardService';
import ViewButton from './ViewButton';
import CommunityBanner from './CommunityBanner';
import '../css/community_banner.css';
import '../css/community.css';




class Community extends Component {
    constructor(props){
        super(props)
        // 1단계 소스 코딩
        this.state = {
            boards: [] //상태값을 보드 배열에 담기
        }
    }

        // 2단계 소스 코딩
        componentDidMount(){
            BoardService.getBoards().then((res) => {
                this.setState({boards: res.data});
            });
        }

    render() {
        return (
            <>
                <Container>
                    <CommunityBanner/>
                    <div className='table_why'>
                        <table className='table_list'>
                            <thead>
                                <tr className='table_thead'>
                                    <th>No.</th>
                                    <th>Title</th>
                                    <th>Content</th>
                                    <th>Writer</th>
                                </tr>
                            </thead>
                            <tbody className='table_tbody'>
                                {
                                    this.state.boards.map( //**map함수 메서드로 반복해서 여러개 가져온다. 
                                    board =>
                                    <tr key = {board.articleId}> {/*key구분*/}
                                            <td>{board.articleId}</td>
                                            <td>{board.articleTitle}</td>
                                            <td>{board.articleContent}</td>
                                            <td>{board.articleWriter}</td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                    </div>
                        <ViewButton />
                        {/* <Link to="/">
                            <button type="button">처음으로!</button>
                        </Link> */}
                </Container>                
            </>
     );
   }
}


export default Community;