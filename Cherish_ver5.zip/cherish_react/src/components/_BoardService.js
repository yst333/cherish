import axios from "axios";

const BOARD_API_BASE_URL = "http://localhost:9008/list.do";

class BoardService {    
    getBoards(){
        //axios.get으로 BoardService를 호출하면 BOARD_API_BASE_URL에 잇는 값을 리턴처리해라
        return axios.get(BOARD_API_BASE_URL); 
    }
}

export default new BoardService;