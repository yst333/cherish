import React from 'react';
import '../css/goods_item.css';


const lights = () => {
    return (
        <div>
           <ul className='GoodsUl'>
                <li className='GoodsLi'>
                    <div>
                    <img src="https://cdn-contents.weverseshop.io/public/shop/1f6792197b6bff2133d2ae368aaa7743.png" alt="뉴진스_응원봉" />
                        <section>
                            <em>Newjeans</em>
                            <p>Light Stick</p>
                            <strong>₩49,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/68b43823716a52272e25fbc9706d26e7.png" alt="르세라핌_응원봉" />
                        <section>
                            <em>LE SSERAFIM</em>
                            <p>Official Light Stick</p>
                            <strong>₩49,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img  src="https://cdn-contents.weverseshop.io/public/shop/73dd1207e5cc51d473d3af34c3e4749c.png" alt="악뮤_응원봉" />
                        <section>
                            <em>AKMU</em>
                            <p>Light Stick VER.2</p>
                            <strong>₩12,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/c0bb0cade706c6aa6e1f830d047924a0.png?q=95&w=720" alt="블랙핑크_응원봉" />
                        <section>
                            <em>BlackPink</em>
                            <p>Official Light Stick VER.2</p>
                            <strong>₩71,400</strong>
                        </section>
                    </div>
                </li>
            </ul>
                       <ul className='GoodsUl'>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/8cbcd523035c896eb36dbaaac83350e9.png" alt="세븐틴_응원봉" />
                        <section>
                            <em>SEVENTEEN</em>
                            <p>Official Light Stick</p>
                            <strong>₩49,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/bb71c3169979d6bb31076bfc7b2d9791.png" alt="펜타곤_응원봉" />
                        <section>
                            <em>Pentagon</em>
                            <p>Official Light Stick</p>
                            <strong>₩49,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/428a690e1aac4fa755ffe5560c7054c1.jpg?q=95&w=720" alt="투모로우바이투게터_응원봉" />
                        <section>
                            <em>TOMORROW X TOGETHER</em>
                            <p>Light Stick</p>
                            <strong>₩39,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/c1a2d4dcbee5d141b3b583974e9c3dba.jpg?q=95&w=720" alt="bts_응원봉" />
                        <section>
                            <em>BTS</em>
                            <p>Light Stick Special Edition</p>
                            <strong>₩49,000</strong>
                        </section>
                    </div>
                </li>
            </ul>
        </div>
    );
};

export default lights;