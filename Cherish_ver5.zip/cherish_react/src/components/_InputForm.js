import React, { Component } from 'react';
import axios from "axios";
import { Link } from 'react-router-dom';
import Community from './Community';
import Container from "react-bootstrap/esm/Container";
import CommunityBanner from './CommunityBanner';
import '../css/input_form.css';


class InputForm extends Component {

    constructor(props){
        super(props);
        this.state = {
            articleId: "",
            articleTitle: "",
            articleContent: "",
            articleWriter: "",
            crud: props.match.params.crud,
        };
        if(this.state.crud !== "Insert"){
            this.getData();
        }
    }

    createHeaderName(){
        const crud = this.state.crud;
        if(crud === "View"){
            return "view";
        } else if(crud === "Update"){
            return "edit";
        } else if(crud === "Delete"){
            return "delete";
        } else if(crud === "Insert"){
            return "write";
        }
    }

    createCrudBtn(){
        const crud = this.state.crud;
        if(crud === "View"){
            return null;
        } else {
            const crudName = 
            crud === "Update" ? "수정" : crud === "Insert" ? "등록" : "삭제";
            return(
                <button className='inputBtn' onClick={() => this.crud()}>게시글 {crudName}</button>
            );
        }
    }

    crud(){
        const {articleId, articleTitle, articleContent, articleWriter, crud} = this.state;

        let crudType = "";
        if(crud === "Update"){
            crudType = "/updateProcess.do";            
        } else if(crud === "Delete"){
            crudType = "/deleteProcess.do"
        } else if(crud === "Insert"){
            crudType = "/insertProcess.do";
        } else if(crud === "View"){
            return null;
        } else if(crud === "Community"){ 
            return Community; 
        }

        let form = new FormData();
        form.append("articleContent", articleContent);
        form.append("articleTitle", articleTitle);
        form.append("articleWriter", articleWriter);
        if(crud !== "Insert"){
            form.append("articleId", articleId);
        }

        axios
         .post(crudType, form)
         .then((res) => {
            alert("요청이 처리되었습니다!");
            this.props.history.push("/Community");
         })
         .catch((err) => alert("error: " + err.response.data.msg));
    }

    getData(){
        axios.get("/view.do").then((res) => {
            const data = res.data;
            this.setState({
                articleId: data.articleId,
                articleTitle: data.articleTitle,
                articleContent: data.articleContent,
                articleWriter: data.articleWriter,
            });
        });
    }

    createArticleIdTag(){
        const articleId = this.state.articleId;
        const crud = this.state.crud;
        if(crud !== "Insert"){
            return <input type="hidden" value = {articleId || ''} readOnly />;
        } else {
            return null;
        }
    }

    render(){
        const articleTitle = this.state.articleTitle;
        const articleContent = this.state.articleContent;
        const articleWriter = this.state.articleWriter;

        return(
            <Container>
                <CommunityBanner />
                <h3 className='createHeaderName'>{this.createHeaderName()}</h3>
                {this.createArticleIdTag()}
                <h3 className='inputTitle'>title</h3>
                <input
                 type="text" className='inputSub'
                 value={articleTitle || ''}
                 onChange={(event) => this.setState({articleTitle: event.target.value})
                }
                />
                <br />
                <h3 className='inputTitle'>content</h3>
                <textarea
                rows="10" className='inputSub'
                value={articleContent || ''}
                onChange={(event) => this.setState({articleContent: event.target.value})
                }
                ></textarea>
                <br />
                <h3 className='inputTitle'>writer</h3>
                <input
                 type="text" className='inputSub'
                 value={articleWriter || ''}
                 onChange={(event) => this.setState({articleWriter: event.target.value})
                }
                />
                <br /> <br />
                {this.createCrudBtn()}
                <Link to="/Community">
                    <button type='button' className='inputBtn'>돌아가기</button>
                </Link>
            </Container>
        );
    } 
}


export default InputForm;