import React, { useState, useEffect } from 'react';
import '../css/QnaBanner.css';

function QnaBanner() {
  const images = [
    'images/image1.jpg',
    'images/image2.jpg',
    'images/image3.jpg',
    'images/image4.jpg',
    'images/image5.jpg',
    'images/image6.jpg',
  ];

  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const goToNextImage = () => {
    setCurrentImageIndex((currentImageIndex + 1) % images.length);
  };

  useEffect(() => {
    const interval = setInterval(goToNextImage, 3000);
    return () => clearInterval(interval);
  }, [currentImageIndex]);

  return (
    <div className="carousel-container">
      <img className='qnaImg' src={images[currentImageIndex]} alt={`Image ${currentImageIndex + 1}`} />
    </div>
  );
}

export default QnaBanner;