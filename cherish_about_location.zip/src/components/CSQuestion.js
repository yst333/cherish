import React from 'react';
import Container from 'react-bootstrap/Container';
import '../css/QnA.css';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

function CSQuestion() {
    return (
        <>
        <Container className='csContainer'>
            <h2 className='csTitle'> 1:1 문의 </h2>
            <Form>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Label>이름</Form.Label>
                    <Form.Control type="text" placeholder="이름을 남겨주세요" />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Label>전화번호</Form.Label>
                    <Form.Control type="text" placeholder="연락처를 남겨주세요" />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                    <Form.Label>문의내용</Form.Label>
                    <Form.Control as="textarea" rows={3} />
                </Form.Group>
                <Button variant="submit" className='qnaButton'>제출하기</Button>
            </Form>
        </Container>
      </>
    );
};

export default CSQuestion;