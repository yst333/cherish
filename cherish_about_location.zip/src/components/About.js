/* eslint-disable no-undef */
import React, { Component, useState, useEffect } from 'react';
import Container from 'react-bootstrap/Container';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMapLocationDot } from "@fortawesome/free-solid-svg-icons";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

import '../css/about.css';

import AOS from "aos";
import "../css/aos.css";

// https://react-bootstrap.netlify.app/docs/components/buttons

const location_name = "Cherish";

class About extends Component {
    componentDidMount() {
        this.kakaoMapScript();
        AOS.init({ duration: 2000 });
    }

    kakaoMapScript() {
        const container = document.getElementById("map");
        const options = {
            center: new kakao.maps.LatLng(37.4770104, 126.8823347),
            level: 5, //확대시켜준것
        };
        // Map 변수에 kakao map 정보를 대입해 줍니다.
        const map = new kakao.maps.Map(container, options);

        // 마커가 표시될 위치를 설정해 줍니다.
        const markerPosition = new kakao.maps.LatLng(37.4770104, 126.8823347);

        // 마커를 생성해 줍니다.
        const marker = new kakao.maps.Marker({
            position: markerPosition,
        });

        // 마커를 지도 위에 표시해 줍니다.
        marker.setMap(map);
    }

    render() {
        return (
            <div>
                <Container>
                <div id="wrap">
                    <div id="container">
                        <div id="contents">
                            <div id="about">
                                <div class="titleArea">
                                    <h2>ABOUT US</h2>
                                </div>
                                <div class="aboutImg">
                                    <div id="aboutVideo" class="video">
                                        <div class="cherishLogo_img">
                                            <img src="/images/video_logo.png" alt="cherishLogo"/>
                                        </div>
                                        <div class="video_frame">
                                            <video playsinline="" muted loop autoplay="" preload="metadata" data-desktop-url="/video/IVE_IAM_MV.mp4" data-mobile-url="/video/IVE_IAM_MV.mp4">
                                                <source src="/video/IVE_IAM_MV.mp4" type="video/mp4"/>
                                            </video>
                                        </div>
                                    </div>                            
                                </div>

                                <div class="page-body">
                                    <div class="bx lbox" data-aos="fade-right">
                                        <dl>
                                            <dt>Cherish</dt>
                                            <dd>
                                                Cherish는 아이돌의 콘서트 일정, 음악, 뮤비, 화보 등을 볼 수 있는 팬 커뮤니티 사이트로 K-POP이 전세계적으로 유행하기 때문에 트렌드에 맞춰 아이돌 팬 - 팬, 팬 - 스타가 소통할 수 있는 공간을 만들었습니다.<br />
                                                현재에는 ZEROBASEONE, SHINee, SEVENTEEN, NewJeans, IVE, aespa 등 Cherish Artist의 앨범, 화보집, 공연 DVD 등과 함께 앨범 굿즈, 콘서트 굿즈까지 다양한 상품들을 판매하고 있습니다.<br />
                                                팬 여러분들이 Cherish를 이용하여 더욱더 편리하게 Cherish Artist의 상품을 구매하고 더 다양한 상품들을 빠르게 받아보실 수 있도록, 좋은 시스템을 갖추기 위해 끊임없이 노력하여 전세계 음악 시장과 소통하며 세계를 뛰어넘어 누구나 공감하고 위로 받는 커뮤니티를 만들겠습니다.
                                            </dd>
                                        </dl>
                                    </div>
                                    <div class="bx rbox" p data-aos="fade-left">
                                        <dl>
                                            <dt>Cherish in your AREA</dt>
                                            <dd>
                                                덕질도 사랑이다! Cherish는 팬 커뮤니케이션 공간입니다!<br />
                                                함께 덕질할 친구도 만나고, 내 최애도 자랑하고!<br />
                                                서로의 사진을 공유하며 즐거움도 행복함도 가득 얻어가시길 바랍니다!
                                            </dd>
                                        </dl>
                                        <dl>
                                            <dt>Cherish Artist</dt>
                                            <dd>
                                                ZEROBASEONE, SHINee, SEVENTEEN, NewJeans, IVE, aespa
                                            </dd>
                                        </dl>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="wrap">
                    <div id="container">                    
                        <div class="section_box ci">
                            <div class="tit_box">
                                <span class="b_txt">CI</span>
                            </div>
                            <div class="ci_box">
                                <div class="l_box">
                                    <span class="ci_img_label">CI</span>
                                    <div class="ci_img">
                                        <img src="/images/cherish_logo.png" alt="CI 이미지입니다." title="CI 이미지입니다." />
                                    </div>
                                </div>
                            <div class="r_box">
                                <div class="top_b">
                                    <span class="ci_img_label">SYMBOL</span>
                                    <div class="ci_img">
                                        <img src="/images/cherish_symbol.png" alt="SYMBOL 이미지입니다." title="SYMBOL 이미지입니다." />
                                    </div>
                                </div>
                                <div class="bottom_b">
                                    <span class="ci_img_label">WORDMARK</span>
                                    <div class="ci_img">
                                        <img src="/images/cherish_wordmark.png" alt="WORDMARK 이미지입니다." title="WORDMARK 이미지입니다." />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="ci_color">
                            <div class="c_primary">
                                <span class="ci_img_label">Primary Colors</span>
                                <ul>
                                    <li class="pink">
                                        <span class="ci_color_label">#F8488F</span>
                                    </li>
                                    <li class="navy">
                                        <span class="ci_color_label">#1A1244</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="c_accent">
                                <span class="ci_img_label">Accent Color</span>
                                <div class="mint">
                                    <span class="ci_color_label">#4DD3B4</span>
                                </div>
                            </div>
                        </div>                                
                        </div>
                    </div>
                </div>
                </Container>
                
                <Container>
                <Row className="location_common">
                    <Col><h1>Where is {location_name} ?</h1>   </Col>
                    <Col>
                        <p className='location_info'><FontAwesomeIcon icon={faMapLocationDot} className='icon'/> 서울시 금천구 체리쉬로 체리쉬빌딩(06070)</p>
                    </Col>
                </Row>
                {/* 카카오맵 정보가 들어올 id 속성값으로 map을 div 영역에 정의해 줍니다 */}
                <div id="map"></div>                 
                </Container>   
            </div>
        );
    }
}

export default About;