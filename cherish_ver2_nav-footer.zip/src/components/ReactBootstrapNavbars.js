import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import "../css/common.css";

// react-bootstrap/Navbar
// https://react-bootstrap.netlify.app/docs/components/navbar/

function ReactBootstrapNavbars() {
  return (
    <>
      <div className="navbarbg">
      <Navbar bg="light" expand="lg">
        <Container>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto" >
              <div className='ABOUT mx-4'><Nav.Link href="/About" >ABOUT</Nav.Link></div>
              <div className='GOODS mx-4'><Nav.Link href="/Goods" >GOODS</Nav.Link></div>
              <div className='FAQs mx-4'><Nav.Link href="/Faqs" >FAQs</Nav.Link></div>
              <div className='COMMUNITY mx-4'><Nav.Link href="/Community" >COMMUNITY</Nav.Link></div>     
              <Navbar.Brand href="/" className='logo'><img src='/images/cherish_navlogo.svg' alt='로고이미지' /></Navbar.Brand>
          
            </Nav>
            {/* https://react-bootstrap.netlify.app/docs/forms/form-control */}
            {/* d-flex는 flex 적용 의미함 */}
            <Form className='d-flex justify-content-left'>
              <div className='LOGIN mx-4' ><Nav.Link href="/Login" >LOGIN</Nav.Link></div>
              <div className='JOIN mx-4'><Nav.Link href="/Join" >JOIN</Nav.Link></div>
              <div className='MY mx-4'><Nav.Link href="/MY" >MY </Nav.Link></div>

            {/* .me-2는 margin-end 0.5rem Size 적용 의미함 */}
            {/* aria-label은 값에 간결한 설명을 제공해서, 문자열을 통해 현재 엘리먼트의 기능/목적을 설명함 */}
            {/* <Form.Control type="search" className='me-2' placeholder="커뮤니티 검색" aria-label='Search' /> */}
            {/* https://react-bootstrap.netlify.app/docs/components/buttons */}
            {/* <Button variant="outline-success" className='searchBtn'>검색</Button> */}
            </Form>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      </div>
      </>
  );
}

export default ReactBootstrapNavbars;