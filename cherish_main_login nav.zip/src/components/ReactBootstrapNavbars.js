import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import "../css/common.css";

// react-bootstrap/Navbar
// https://react-bootstrap.netlify.app/docs/components/navbar/

function ReactBootstrapNavbars() {
  return (
    <>
      <div>
      <Navbar expand="lg"  className="navbarbg">
        <Container>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className='me-auto align-items-center' >
              <div className='ABOUT mx-3'><Nav.Link href="/About" >ABOUT</Nav.Link></div>
              <div className='GOODS mx-3'><Nav.Link href="/Goods" >GOODS</Nav.Link></div>
              <div className='FAQs mx-3'><Nav.Link href="/Faqs" >FAQs</Nav.Link></div>
              <div className='COMMUNITY mx-3'><Nav.Link href="/Community" >COMMUNITY</Nav.Link></div>     
              <Navbar.Brand href="/" className='logo'><img src='/images/cherish_navlogo.svg' alt='로고이미지' /></Navbar.Brand>
            </Nav>
            
              <Form className='d-flex align-items-center'>
                <div className='LOGIN mx-4' ><Nav.Link href="/Login" >LOGIN</Nav.Link></div>
                <div className='JOIN mx-4'><Nav.Link href="/Join" >JOIN</Nav.Link></div>
                <div className='MY_Page mx-4'><Nav.Link href="/MY_Page" >MY PAGE</Nav.Link></div>
              </Form>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      </div>
      </>
  );
}

export default ReactBootstrapNavbars;