import React from "react";
import Container from 'react-bootstrap/Container';

import Carousel from 'react-bootstrap/Carousel';

import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

import 'bootstrap/dist/css/bootstrap.css';
import '../css/home.css';

import $ from "jquery";
import ReactPlayer from "react-player";

import ReactCalendar from "react-calendar";
import '../css/Calendar.css'





// Carousels 맨 위에 Examples
// https://react-bootstrap.netlify.app/docs/components/carousel/

const Home = () => {

    
    return(   
        <>
            <div className="wrapper"> 
                {/* 배너 영상 */}
                <div className='player'>
                    <ReactPlayer
                        // 컴포넌트에서 public 경로에 있는 동영상 위치 지정
                        url={process.env.PUBLIC_URL + '/video/cool.mp4'}
                        // 플레이어 크기(폭, 가로)
                        width='100%'
                        // 플레이어 크기(높이, 세로)
                        height='100%'
                        // 자동 실행 설정(true)
                        playing={true}                   
                        // 음소거 설정(true)
                        // 참고로, 자동 재생 설정은 playing과 muted를 true로 설정해야 합니다.
                        muted={true}
                        // 플레이어 컨트롤 노출 설정(true)
                        controls={true}
                        // 반복 재생 설정(true)
                        loop={true}
                    />
                </div>               
                <Container>
                    <div className="mycherish">
                        <h2 className="m_title">MY CHERISH</h2>
                        <em className="seeall">SEE ALL</em>
                        <ul className="artist clearfix">
                            <li>
                                <a href="#"><img src="/images/zerobaseone.svg" alt="제로베이스원"></img></a>
                                <span className="singer">ZeroBaseOne</span>
                            </li>
                            <li>
                                <a href="#"><img src="/images/shinee.svg" alt="샤이니"></img></a>
                                <span className="singer">SHINee</span>
                            </li>
                            <li>
                                <a href="#"><img src="/images/seventeen.svg" alt="세븐틴"></img></a>
                                <span className="singer">SEVENTEEN</span>
                            </li>
                            <li>
                                <a href="#"><img src="/images/ive.svg" alt="아이브"></img></a>
                                <span className="singer">IVE</span>
                            </li>
                            <li>
                                <a href="#"><img src="/images/newjeans.svg" alt="뉴진스"></img></a>
                                <span className="singer">NEWJEANS</span>
                            </li>
                            <li className="aespa">
                                <a href="#"><img src="/images/aespa3.svg" alt="에스파"></img></a>
                                <span className="singer">AESPA</span>
                            </li>
                        </ul>
                    </div>
                    {/* Popularity of the WEEK */}
                    <div className="Popularity">
                        <h2 className="m_title">POPULARITY OF THE WEEK</h2>
                        <em className="weekly">Weekley</em>
                        <div className="vs clearfix">
                            <article>
                                <img src="/images/kingcarina.svg" alt="카리나"></img>
                                <span className="grade">1st</span>
                            </article>
                            <b>VS</b>
                            <article className="daniel">
                                <img src="/images/daniel.svg" alt="다니엘"></img>
                                <span className="grade">2nd</span>
                            </article>
                        </div>
                    </div>
                </Container>
                {/* pictorial */}
                <div className="carousel_tabs_cont pictorial">
                    <div className="carouselcont">
                        <Carousel>
                            <Carousel.Item>
                                <img
                                className="d-block w-100"
                                src="/images/vui.svg"
                                alt="First slide"
                                />
                                <Carousel.Caption>                                
                                </Carousel.Caption>
                            </Carousel.Item>
                            <Carousel.Item>
                                <img
                                className="d-block w-100"
                                src="/images/mixx.svg"
                                alt="Second slide"
                                />
                                <Carousel.Caption>                                
                                </Carousel.Caption>
                            </Carousel.Item>
                            <Carousel.Item>
                                <img
                                className="d-block w-100"
                                src="/images/seventeen2.svg"
                                alt="Third slide"
                                />
                                <Carousel.Caption>                                
                                </Carousel.Caption>
                            </Carousel.Item>
                        </Carousel>
                    </div>         
                </div>
            </div>

            {/* schedule */}
            <Container>
                <div className="schedule">
                    <h2 className="m_title">My CHERISH’<br></br> SCHEDULE </h2>
                </div>
                <div className="calendar">
                    <select className="artistselect">
                        <option>아티스트 선택</option>
                        <option>ZeroBaseOne</option>
                        <option>SHINee</option>
                        <option>SEVENTEEN</option>
                        <option>IVE</option>
                        <option>NEWJEANS</option>
                        <option>AESPA</option>
                    </select>
                    <ReactCalendar>
                    </ReactCalendar>
                </div>
            </Container>    
            
        </>     
    );
};
export default Home;

$(function(){
    $(".media01").delay(100).animate({opacity:1, top: 0}, 600, "swing")
    $(".media02").delay(100).animate({opacity:1, top: 0}, 600, "swing")
    $(".media03").delay(100).animate({opacity:1, top: 0}, 600, "swing")
    $(".media04").delay(100).animate({opacity:1, top: 0}, 600, "swing")
    $(".media05").delay(100).animate({opacity:1, top: 0}, 600, "swing")
});