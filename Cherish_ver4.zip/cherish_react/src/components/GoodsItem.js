import React from 'react';
import '../css/GoodsItem.css';

const GoodsItem = () => {

    return (
        <div>
           <ul className='GoodsUl'>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/5251f5f10ebaf285ad49deb9663b8584.png" alt="뉴진스_응원봉" />
                        <section>
                            <em>Newjeans</em>
                            <p>'GOLDdd</p>
                            <strong>₩71,400</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img class="PcArtistPediaWeverseShopArrivalItemView_image__ihdkV" src="https://cdn-contents.weverseshop.io/public/shop/762333f85ca432cefe6ffbed89d6ef9d.png" alt="" />
                        <section>
                            <em>bts</em>
                            <p>'GOL </p>
                            <strong>₩71,400</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img class="PcArtistPediaWeverseShopArrivalItemView_image__ihdkV" src="https://cdn-contents.weverseshop.io/public/shop/9fbd5cbf8401a7958074e7fa7b6dd3a7.png" alt="" />
                        <section>
                            <em>bts</em>
                            <p>'GOLDddt </p>
                            <strong>₩71,400</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img class="PcArtistPediaWeverseShopArrivalItemView_image__ihdkV" src="https://cdn-contents.weverseshop.io/public/shop/b75612cdbaf79232d27bef1b925b8804.png" alt="" />
                        <section>
                            <em>bts</em>
                            <p>'GOLDddd</p>
                            <strong>₩71,400</strong>
                        </section>
                    </div>
                </li>
            </ul>
        </div>
    );
};

export default GoodsItem;