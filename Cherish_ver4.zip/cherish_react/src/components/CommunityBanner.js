import React from 'react';
import Container from 'react-bootstrap/Container';



const CommunityBanner = () => {
    return (
        <Container>
        <section className='commu_artist'>
            <img className="commu_logo" src='/images/Cherish_logo_render.svg' alt='르세라핌_이미지'/>
            <img className="commu_img" src='/images/lesserafim_board.svg' alt='로고_이미지'/>
        </section>
        <h3 className='CommTitle'>Community</h3>
    </Container>  
    );
};


export default CommunityBanner;