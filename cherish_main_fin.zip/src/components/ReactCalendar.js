import React, { useState } from 'react';
import Calendar from 'react-calendar';
// import '../css/Calendar.css'
import moment from "moment";


function ReactCalendar() {
  const [value, onChange] = useState(new Date()); // 초기값은 현재 날짜

  return (
    <div>
      <Calendar
        onChange={handleDateChange}
        value={value}
        formatDay={(locale, date) => moment(date).format("DD")}>
     </Calendar>
    </div>
  );
}

export default ReactCalendar;