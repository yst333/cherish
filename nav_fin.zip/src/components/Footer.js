import React from "react";
import Container from 'react-bootstrap/Container';

const url = "https://www.kcc.go.kr/user.do";

const Footer = () => {
    return(
        <div className="footerbg">
            <Container>
                <div className="ftWrap">
                    <div className="ft_catch">
                        <img src="/images/cherish_footerlogo.svg" alt="체리쉬푸터로고" className="height: 20px;" />
                    </div>
                    <div className="ft_company">
                        <p className="ft_address">서울 금천구 체리쉬로 체리쉬빌딩(06070) <br/>스타쉽ENT의 모든 컨텐츠는 저작권의 보호를 받고 있습니다.</p>
                        <p className="copyright">Copyright ©CHERISH All rights reserved for portfolio<br/>정보영·어예진·조수정·조윤채·유승태</p>
                    </div>
                    <ul className="ft_info">
                        <li className="contact">CONTACT</li>
                        <li className="sns_bottom">
                            <light>Cherish by like this good</light><br />
                            <span className="sns">
                                <a href="https://www.instagram.com/kkbyss/" target="_blank"><img src="/images/insta.svg" alt="인스타그램" /></a>
                            </span>
                            <span className="sns">
                                <a href="https://twitter.com/kkbyss_official" target="_blank"><img src="/images/twitter.svg" alt="트위터" /></a>
                            </span>
                            <span className="sns">
                                <a href="https://www.youtube.com/channel/UCfj1cHTYDjPrbGtcGKradvA" target="_blank"><img src="/images/youtube.svg" alt="유튜브" /></a>
                            </span>
                        </li>
                    </ul>
                </div>
            </Container>
        </div>
    );
};

export default Footer;